package io.keepcoding.spark.exercise.streaming

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration.Duration
import scala.concurrent.{Await, Future}

object AntennaStreamingJob extends StreamingJob {

  //Construccion de estancia Spark
  override val spark: SparkSession = SparkSession
    .builder()
    .master("local[20]")
    .appName("Final Exercise SQL Streaming")
    .getOrCreate()

  import spark.implicits._

  //Leemos los datos de devices con los mensajes del topico desde Kafka
  override def readFromKafka(kafkaServer: String, topic: String): DataFrame = {
    spark
      .readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", kafkaServer)
      .option("subscribe", topic)
      .load()
  }

  //Parseo de Json a DataFrame {timestamp,id,antenna_id,app,bytes} => |timestamp|id|antenna_id|app|bytes|
  override def parserJsonData(dataFrame: DataFrame): DataFrame = {
    var jsonSchema = StructType(Seq(
      StructField("timestamp", TimestampType, nullable = false),
      StructField("id", StringType, nullable = false),
      StructField("antenna_id",StringType, nullable = false),
      StructField("app", StringType, nullable = false),
      StructField("bytes", IntegerType, nullable = false)
    )

    )
    dataFrame
      .select(from_json(col("value").cast(StringType), jsonSchema).as("json"))
      .select("json.*")
      //.withColumn("timestamp", $"timestamp".cast(TimestampType))
  }

  //Obtencion de metadatos de Usuarios |id|name|email|quota| desde la base de datos de postgres
  override def readAntennaMetadata(jdbcURI: String, jdbcTable: String, user: String, password: String): DataFrame = {
    spark
      .read
      .format("jdbc")
      .option("url", jdbcURI)
      .option("dbtable", jdbcTable)
      .option("user", user)
      .option("password", password)
      .load()
  }

  //Join de los dataFrame de Users y Devices
  override def enrichAntennaWithMetadata(antennaDF: DataFrame, metadataDF: DataFrame): DataFrame = {
    antennaDF.as("antenna")
      .join(
        metadataDF.as("metadata"),
        $"antenna.id" === $"metadata.id"
      ).drop($"metadata.id")
  }

  //Obtencion del total de Bytes de Antenna, User y App
  override def computeBytes(dataFrame: DataFrame, xType: String): DataFrame = xType match{
    case "antenna" =>
      dataFrame
        .select($"id".as("user_id"), $"antenna_id", $"app".as("app_id"), $"timestamp", $"bytes")
        .withWatermark("timestamp", "1 seconds") // "1 minute"
        .groupBy(window($"timestamp", "30 seconds"), $"antenna_id") // "5 minutes"
        .agg(
          sum("bytes").as("value")
        )
        .withColumn("timestamp",$"window.start")
        .withColumn("id",$"antenna_id")
        .withColumn("type",lit("antenna_total_bytes"))
        .select($"timestamp", $"id", $"value", $"type")
        //.select($"window.start".as("timestamp"), $"antenna_id".as("id"), $"value", lit(s"antenna_total_bytes").as("type"))
    case "user" =>
      dataFrame
        .select($"id".as("user_id"), $"antenna_id", $"app".as("app_id"), $"timestamp", $"bytes")
        .withWatermark("timestamp", "1 seconds") // "1 minute"
        .groupBy(window($"timestamp", "30 seconds"), $"user_id") // "5 minutes"
        .agg(
          sum("bytes").as("value")
        )
        .select($"window.start".cast(TimestampType).as("timestamp"), $"user_id".as("id"), $"value", lit(s"user_total_bytes").as("type"))
    case "app" =>
      dataFrame
        .select($"id".as("user_id"), $"antenna_id", $"app".as("app_id"), $"timestamp", $"bytes")
        .withWatermark("timestamp", "1 seconds") // "1 minute"
        .groupBy(window($"timestamp", "30 seconds"), $"app_id") // "5 minutes"
        .agg(
          sum("bytes").as("value")
        )
        .select($"window.start".cast(TimestampType).as("timestamp"), $"app_id".as("id"), $"value", lit(s"app_total_bytes").as("type"))
  }

  override def computeBytesQuota(dataFrame: DataFrame): DataFrame = {
      dataFrame
        .select($"id", $"timestamp", $"bytes", $"quota", $"email")
        .withWatermark("timestamp", "1 seconds") // "1 minute"
        .groupBy(window($"timestamp", "30 seconds"), $"id") // "5 minutes"
        .agg(
          sum("bytes").as("usage"),
          sum("quota").as("quota")
        )
        //.withColumn("email",$"email")
        .withColumn("usage",$"usage")
        .withColumn("quota",$"quota")
        .withColumn("timestamp", $"window.start")
        .select($"usage",$"quota",$"timestamp")
  }

  //Guardamos por cada batch en la base de datos de postgres
  override def writeToJdbc(dataFrame: DataFrame, jdbcURI: String, jdbcTable: String, user: String, password: String): Future[Unit] = Future {
    dataFrame
      .writeStream
      .foreachBatch { (data: DataFrame, batchId: Long) =>
        data
          .write
          .mode(SaveMode.Append)
          .format("jdbc")
          .option("driver", "org.postgresql.Driver")
          .option("url", jdbcURI)
          .option("dbtable", jdbcTable)
          .option("user", user)
          .option("password", password)
          .save()
      }
      .start()
      .awaitTermination()
  }

  //Guardamos por cada batch en un storage local
  override def writeToStorage(dataFrame: DataFrame, storageRootPath: String): Future[Unit] = Future {
    var columns = dataFrame.columns.map(col).toSeq ++
      Seq(
        year($"timestamp").as("year"),
        month($"timestamp").as("month"),
        dayofmonth($"timestamp").as("day"),
        hour($"timestamp").as("hour")
      )
    dataFrame
      .select(columns:_*)
      .writeStream
      .partitionBy("year", "month", "day", "hour")
      .format("parquet")
      .option("path", s"${storageRootPath}/data")
      .option("checkpointLocation", s"${storageRootPath}/checkpoint")
      .start
      .awaitTermination()
  }

  /**
   * Main for Streaming job
   *
   * @param args arguments for execution:
   *             kafkaServer topic jdbcUri jdbcMetadataTable aggJdbcTable jdbcUser jdbcPassword storagePath
   * Example:
   *   XXX.XXX.XXX.XXX:9092 antenna_telemetry jdbc:postgresql://XXX.XXX.XXX.XXXX:5432/postgres metadata antenna_agg postgres keepcoding /tmp/batch-storage
   */
  // Puedes descomentar este main y llamar con argumentos
  //def main(args: Array[String]): Unit = run(args)


  def main(args: Array[String]): Unit = {
    //run(args)
    val kafkaDF = readFromKafka("34.28.76.110:9092", "devices")
    val parsedDF = parserJsonData(kafkaDF)
    val storageFuture = writeToStorage(parsedDF, "/tmp/antenna_parquet/")
    val metadaDF = readAntennaMetadata(
      "jdbc:postgresql://34.171.245.100:5432/postgres",
     "user_metadata",
      "postgres",
      "keepcoding"
    )
    val enrichDF = enrichAntennaWithMetadata(parsedDF, metadaDF)

    val aggBytesAntenna = computeBytes(enrichDF,"antenna")
    val aggBytesUsers = computeBytes(enrichDF,"user")
    val aggBytesApp = computeBytes(enrichDF,"app")

    aggBytesApp
      .writeStream
      .format("console")
      .start()
      .awaitTermination()

    //pruebas
    //val aggBytesQuota = computeBytesQuota(enrichDF)
    //val aggBytesall = aggBytesAntenna.union(aggBytesUsers).union(aggBytesApp)
    //val jdbcFutureAntenna = writeToJdbc(aggBytesall, "jdbc:postgresql://34.171.245.100:5432/postgres", "bytes", "postgres", "keepcoding")

    val jdbcFutureAntenna = writeToJdbc(aggBytesAntenna, "jdbc:postgresql://34.171.245.100:5432/postgres", "bytes", "postgres", "keepcoding")
    val jdbcFutureUsers = writeToJdbc(aggBytesUsers, "jdbc:postgresql://34.171.245.100:5432/postgres", "bytes", "postgres", "keepcoding")
    val jdbcFutureApp = writeToJdbc(aggBytesApp, "jdbc:postgresql://34.171.245.100:5432/postgres", "bytes", "postgres", "keepcoding")

    Await.result(
      //Future.sequence(Seq(storageFuture, jdbcFutureAntenna,jdbcFutureUsers,jdbcFutureApp)), Duration.Inf
      Future.sequence(Seq(storageFuture,jdbcFutureAntenna,jdbcFutureUsers,jdbcFutureApp)), Duration.Inf
      //Future.sequence(Seq(storageFuture,jdbcFutureAntenna)), Duration.Inf
    )
    spark.close()
  }
}
