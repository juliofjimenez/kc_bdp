package io.keepcoding.spark.exercise.batch

import java.time.OffsetDateTime

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DoubleType
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

object AntennaBatchJob extends BatchJob {

  override val spark: SparkSession = SparkSession
    .builder()
    .master("local[*]")
    .appName("Final Exercise SQL Batch")
    .getOrCreate()

  import spark.implicits._

  override def readFromStorage(storagePath: String, filterDate: OffsetDateTime): DataFrame = {
    spark
      .read
      .format("parquet")
      .load(s"${storagePath}/data")
      .filter(
        $"year" === filterDate.getYear &&
          $"month" === filterDate.getMonthValue &&
          $"day" === filterDate.getDayOfMonth &&
          $"hour" === filterDate.getHour
      )
  }

  override def readFromStorageJson(pathJson: String): DataFrame = {
    spark
      .read
      .json(pathJson)
  }

  override def readAntennaMetadata(jdbcURI: String, jdbcTable: String, user: String, password: String): DataFrame = {
    spark
      .read
      .format("jdbc")
      .option("url", jdbcURI)
      .option("dbtable", jdbcTable)
      .option("user", user)
      .option("password", password)
      .load()
  }

  override def enrichAntennaWithMetadata(antennaDF: DataFrame, metadataDF: DataFrame): DataFrame = {
    antennaDF.as("antenna")
      .join(
        metadataDF.as("metadata"),
        $"antenna.id" === $"metadata.id"
      ).drop($"metadata.id")
  }

  override def computeBytes(dataFrame: DataFrame): DataFrame = {
    dataFrame
      //.select($"id".as("user_id"), $"antenna_id", $"app".as("app_id"), $"timestamp", $"bytes")
      .withWatermark("timestamp", "1 seconds") // "1 minute"
      .groupBy(window($"timestamp", "30 seconds"), $"antenna_id") // "5 minutes"
      .agg(
        sum("bytes").as("value")
      )
      .withColumn("timestamp", $"window.start")
      .withColumn("id", $"antenna_id")
      .withColumn("type", lit("antenna_total_bytes"))
      .select($"timestamp", $"id", $"value", $"type")
  }

  override def computeBytesUserQuotaLimit(dataFrame: DataFrame): DataFrame = {
    dataFrame
      .select(
        $"id",
        $"name",
        $"email",
        $"quota",
        $"bytes"
      ).withWatermark("timestamp", "1 seconds")
      .groupBy(window($"timestamp", "30 seconds"))
      .agg(sum("bytes").as("usage"))
      .withColumn("timestamp", $"window.start")
      .select($"email", $"usage", $"quota", $"timestamp")
  }

  override def writeToJdbc(dataFrame: DataFrame, jdbcURI: String, jdbcTable: String, user: String, password: String): Unit = {
    dataFrame
      .write
      .mode(SaveMode.Append)
      .format("jdbc")
      .option("driver", "org.postgresql.Driver")
      .option("url", jdbcURI)
      .option("dbtable", jdbcTable)
      .option("user", user)
      .option("password", password)
      .save()
  }

  override def writeToStorage(dataFrame: DataFrame, storageRootPath: String): Unit = {
    dataFrame
      .write
      .partitionBy("year", "month", "day", "hour")
      .format("parquet")
      .mode(SaveMode.Overwrite)
      .save(s"${storageRootPath}/historical")
  }

  /**
   * Main for Batch job
   *
   * @param args arguments for execution:
   *             filterDate storagePath jdbcUri jdbcMetadataTable aggJdbcTable aggJdbcErrorTable aggJdbcPercentTable jdbcUser jdbcPassword
   * Example:
   *   2007-01-23T10:15:30Z /tmp/batch-storage jdbc:postgresql://XXX.XXX.XXX.XXXX:5432/postgres metadata antenna_1h_agg antenna_errors_agg antenna_percent_agg postgres keepcoding
   */
  // puedes descomentar este main para pasar parametros a la ejecucion
  //def main(args: Array[String]): Unit = run(args)

  def main(args: Array[String]): Unit = {
    val jdbcUri = "jdbc:postgresql://34.171.245.100:5432/postgres"
    val jdbcUser = "postgres"
    val jdbcPassword = "keepcoding"

    val offsetDateTime = OffsetDateTime.parse("2022-10-30T13:00:00Z")
    val parquetDF = readFromStorage("C:/tmp/antenna_parquet/", offsetDateTime)
    val metadataDF = readAntennaMetadata(
      "jdbc:postgresql://34.171.245.100:5432/postgres",
      "user_metadata",
      "postgres",
      "keepcoding"
    )
    val antennaMetadataDF = enrichAntennaWithMetadata(parquetDF, metadataDF).cache()

    val aggByte = computeBytes(antennaMetadataDF)
    val aggByteUserQuota = computeBytesUserQuotaLimit(antennaMetadataDF)

    val jdbcByte = writeToJdbc(aggByte, "jdbc:postgresql://34.171.245.100:5432/postgres", "bytes_hourly", "postgres", "keepcoding")
    val jdbcByteUserQuota = writeToJdbc(aggByteUserQuota, "jdbc:postgresql://34.171.245.100:5432/postgres", "bytes_hourly", "postgres", "keepcoding")

    spark.close()
  }
}
